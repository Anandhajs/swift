//
//  customCollectionViewCell.swift
//  loadData
//
//  Created by Keerthi on 12/04/22.
//

import UIKit

class customCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var imageLbl: UILabel!
    
    
    
    
}
