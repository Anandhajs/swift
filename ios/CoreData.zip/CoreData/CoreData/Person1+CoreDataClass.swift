//
//  Person1+CoreDataClass.swift
//  CoreData
//
//  Created by Keerthi on 02/04/22.
//
//

import Foundation
import CoreData

@objc(Person1)
public class Person1: NSManagedObject {

}
