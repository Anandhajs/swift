//
//  Person1+CoreDataProperties.swift
//  CoreData
//
//  Created by Keerthi on 02/04/22.
//
//

import Foundation
import CoreData


extension Person1 {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Person1> {
        return NSFetchRequest<Person1>(entityName: "Person1")
    }

    @NSManaged public var age: String?
    @NSManaged public var name: String?

}

extension Person1 : Identifiable {

}
