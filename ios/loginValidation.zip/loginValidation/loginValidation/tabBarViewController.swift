//
//  tabBarViewController.swift
//  loginValidation
//
//  Created by Keerthi on 18/03/22.
//

import UIKit

class tabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
